This is a Whack-a-Mole/Fly-Swatter hybrid game.

Move the swatter around with the arrow keys. When the swatter is above a fly, press A to swat it!

Keep the number of flies below 5. If you're at 4, and another fly spawns, you will lose.

If you kill all the flies, you win!

Press select to reset the game at any state.