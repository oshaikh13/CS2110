/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=20x20 swatter swatter.png 
 * Time-stamp: Saturday 11/16/2019, 03:28:29
 * 
 * Image Information
 * -----------------
 * swatter.png 20@20
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SWATTER_H
#define SWATTER_H

extern const unsigned short swatter[400];
#define SWATTER_SIZE 800
#define SWATTER_LENGTH 400
#define SWATTER_WIDTH 20
#define SWATTER_HEIGHT 20

#endif

