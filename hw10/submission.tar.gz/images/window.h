/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 window window.png 
 * Time-stamp: Thursday 11/14/2019, 15:13:22
 * 
 * Image Information
 * -----------------
 * window.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef WINDOW_H
#define WINDOW_H

extern const unsigned short window[38400];
#define WINDOW_SIZE 76800
#define WINDOW_LENGTH 38400
#define WINDOW_WIDTH 240
#define WINDOW_HEIGHT 160

#endif

